# PixelCore - Demo Version

Welcome to the PixelCore Demo!

PixelCore is a creative application designed for pixel art creation and 2D character design.

## About This Demo
This is an early demo version of PixelCore. It allows users to explore the application and test its available features.

## Important Notes
- This is a testing version.
- Some features may be incomplete.
- Bugs and unexpected behavior may occur.
- Your feedback helps improve PixelCore.

## Developer
Created by Mohamed Samy.

## Version
PixelCore Demo - Version 0.1

**Thank you for testing PixelCore!**
